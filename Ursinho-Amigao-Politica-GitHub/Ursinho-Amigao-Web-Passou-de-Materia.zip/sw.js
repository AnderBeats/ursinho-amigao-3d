const cacheName = 'ursinho-offline-46755E90A625';
const assets = [
    './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png',
    './audio/abertura-fim.mp3', './colorir/Turma-Colorida.jpg', './colorir/Turma-Para-Colorir.png', './colorir/Ursinho-Ferias.jpg', './colorir/Ferias-Para-Colorir.png', './colorir/Ursinho-Lado-a-Lado.png', './colorir/Tito-Lado-a-Lado.png', './colorir/Gina-Lado-a-Lado.png', './colorir/Lili-Lado-a-Lado.png', './colorir/Cartilha-Ursinho-Para-Colorir.zip',
    ...Array.from({length: 12}, (_, index) => './audio/' + String(index + 1).padStart(2, '0') + '.mp3')
];
self.addEventListener('install', event => {
    event.waitUntil(caches.open(cacheName).then(cache => cache.addAll(assets)));
});
self.addEventListener('activate', event => {
    event.waitUntil((async () => {
        const names = await caches.keys();
        await Promise.all(names.filter(name => name.startsWith('ursinho-offline-') && name !== cacheName).map(name => caches.delete(name)));
        await self.clients.claim();
    })());
});
self.addEventListener('fetch', event => {
    const request = event.request;
    if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
    if (request.mode === 'navigate') {
        event.respondWith(fetch(request).catch(async () => (await caches.open(cacheName)).match('./index.html')));
        return;
    }
    const path = new URL(request.url).pathname;
    if (path.includes('/colorir/')) {
        event.respondWith(caches.open(cacheName).then(async cache => (await cache.match(request)) ?? fetch(request)));
        return;
    }
    if (!path.includes('/audio/')) return;
    event.respondWith((async () => {
        const cached = await (await caches.open(cacheName)).match(request.url, {ignoreSearch: true});
        if (!cached) return fetch(request);
        const range = request.headers.get('range')?.match(/^bytes=(\d+)-(\d*)$/);
        if (!range) return cached;
        const bytes = await cached.arrayBuffer();
        const start = Number(range[1]);
        const end = range[2] ? Math.min(Number(range[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
        if (start > end) return new Response(null, {status: 416, headers: {'Content-Range': 'bytes */' + bytes.byteLength}});
        return new Response(bytes.slice(start, end + 1), {
            status: 206,
            headers: {'Content-Type': 'audio/mpeg', 'Content-Length': end - start + 1, 'Content-Range': 'bytes ' + start + '-' + end + '/' + bytes.byteLength}
        });
    })());
});