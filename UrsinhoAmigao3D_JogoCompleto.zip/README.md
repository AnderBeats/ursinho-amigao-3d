# Ursinho Amigão 3D - Fase 1

Este repositório contém os arquivos do jogo 3D estilo Minecraft.

## Como publicar no Vercel

1. Acesse https://vercel.com
2. Clique em "Import Git Repository" e selecione `ursinho-amigao-3d`
3. Faça o upload dos arquivos deste repositório
4. Vercel criará automaticamente um link do tipo:
   https://ursinho-amigao-3d.vercel.app

## Como testar localmente

1. Baixe este repositório como .zip
2. Extraia os arquivos
3. Abra o arquivo `index.html` no navegador
